package com.au.recyclerview;

public class Product {

    private int pid;
    private  String title;
    private  int pimg;

    public Product(int pid, String title, int pimg) {
        this.pid = pid;
        this.title = title;
        this.pimg = pimg;
    }

    public int getPid() {
        return pid;
    }

    public String getTitle() {
        return title;
    }

    public int getPimg() {
        return pimg;
    }

    /*public Product(int pid,String title,int pimg){
        this.pid=pid;
        this.title=title;
        this.pimg=pimg;
    }

    public int getPid()
    {
        return  pid;
    }
    public int getPim1g()
    {
        return pimg;
    }
    public String getTitle()
    {
        return title;
    }*/




}
