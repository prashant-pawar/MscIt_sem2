package com.au.recyclerview;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    List<Product> pl;
    RecyclerView rvdisplay;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

            rvdisplay=findViewById(R.id.rvdisplay);
            rvdisplay.setHasFixedSize(true);
            rvdisplay.setLayoutManager(new LinearLayoutManager(this));
            pl=new ArrayList<Product>();
            pl.add(new Product(1,"abcxwxcdewc",R.drawable.img1));
            pl.add(new Product(1,"abcxwxcdewc",R.drawable.img2));
            pl.add(new Product(1,"abcxwxcdewc",R.drawable.img3));
            pl.add(new Product(1,"abcxwxcdewc",R.drawable.img4));
            pl.add(new Product(1,"abcxwxcdewc",R.drawable.img5));
            pl.add(new Product(1,"abcxwxcdewc",R.drawable.img6));
            pl.add(new Product(1,"abcxwxcdewc",R.drawable.img7));
            pl.add(new Product(1,"abcxwxcdewc",R.drawable.img1));
            pl.add(new Product(1,"abcxwxcdewc",R.drawable.img2));
            pl.add(new Product(1,"abcxwxcdewc",R.drawable.img3));
            pl.add(new Product(1,"abcxwxcdewc",R.drawable.img4));
            pl.add(new Product(1,"abcxwxcdewc",R.drawable.img5));
            pl.add(new Product(1,"abcxwxcdewc",R.drawable.img6));
            pl.add(new Product(1,"abcxwxcdewc",R.drawable.img7));

            ProductAdapter pa=new ProductAdapter(this,pl);
            rvdisplay.setAdapter(pa);
    }









}
