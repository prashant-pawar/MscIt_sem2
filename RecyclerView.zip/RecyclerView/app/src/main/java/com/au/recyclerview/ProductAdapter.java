package com.au.recyclerview;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.lang.reflect.Constructor;
import java.util.List;

public class ProductAdapter extends RecyclerView.Adapter<ProductAdapter.ProductViewHolder>{

    private Context c;
    private List<Product> pl;

    public ProductAdapter(Context c, List<Product> pl) {
        this.c = c;
        this.pl = pl;

    }


    @NonNull
    @Override
    public ProductViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater li=LayoutInflater.from(c);
        View v=li.inflate(R.layout.layout_products,null);
        return new ProductViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull ProductViewHolder holder, int position) {
        Product p=pl.get(position);
        holder.tvtitle.setText(p.getTitle());
        holder.ivimg.setImageDrawable(c.getResources().getDrawable(p.getPimg()));
    }

    @Override
    public int getItemCount() {

        return pl.size();
    }

    class ProductViewHolder extends RecyclerView.ViewHolder
    {
        TextView tvtitle;
        ImageView ivimg;

        public ProductViewHolder(@NonNull View itemView) {
            super(itemView);
            tvtitle=itemView.findViewById(R.id.tvtitle);
            ivimg=itemView.findViewById(R.id.ivimg);

        }

    }
}
