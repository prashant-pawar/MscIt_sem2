package com.au.actionbar;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.ToggleButton;

public class MainActivity extends AppCompatActivity {
    TextView tvdisplay;
    ToggleButton togglebutton;
    ImageView iv1;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        tvdisplay=findViewById(R.id.tvdisplay);
        togglebutton=findViewById(R.id.togglebutton);
        iv1=findViewById(R.id.iv1);

        togglebutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String s=togglebutton.getText().toString();
                tvdisplay.setText(s);

                if (s.equals("onstate"))
                {
                    iv1.setImageResource(R.drawable.img1);
                    tvdisplay.setTextColor(Color.GRAY);
                }
                else {
                    iv1.setImageResource(R.drawable.img2);
                    tvdisplay.setTextColor(Color.MAGENTA);
                }

            }
        });
    }



    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.my_menu,menu);
        //return super.onCreateOptionsMenu(menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId())
        {
            case R.id.add:
            {
                tvdisplay.setText("Add button ");
                break;
            }
            case R.id.Reset:
            {
                tvdisplay.setText("Reset");
                break;
            }
            case R.id.About:
            {
                tvdisplay.setText("About");
               break;
            }
            case R.id.Exit:
            {
                tvdisplay.setText("Exit");
               break;
            }

        }
        return true;//super.onOptionsItemSelected(item);

    }



}
